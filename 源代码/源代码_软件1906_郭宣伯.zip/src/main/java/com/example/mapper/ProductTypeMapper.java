package com.example.mapper;

import com.example.entity.ProductType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface ProductTypeMapper extends BaseMapper<ProductType> {

}
