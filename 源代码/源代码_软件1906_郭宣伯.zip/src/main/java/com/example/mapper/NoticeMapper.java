package com.example.mapper;

import com.example.entity.Notice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface NoticeMapper extends BaseMapper<Notice> {

}
