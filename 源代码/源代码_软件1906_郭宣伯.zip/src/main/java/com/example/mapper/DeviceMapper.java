package com.example.mapper;

import com.example.entity.Device;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface DeviceMapper extends BaseMapper<Device> {

}
