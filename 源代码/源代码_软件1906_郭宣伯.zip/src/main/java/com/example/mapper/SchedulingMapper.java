package com.example.mapper;

import com.example.entity.Scheduling;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface SchedulingMapper extends BaseMapper<Scheduling> {

}
