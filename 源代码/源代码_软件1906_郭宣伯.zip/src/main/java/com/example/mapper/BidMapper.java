package com.example.mapper;

import com.example.entity.Bid;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface BidMapper extends BaseMapper<Bid> {

}
