package com.example.mapper;

import com.example.entity.Capacity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface CapacityMapper extends BaseMapper<Capacity> {

}
