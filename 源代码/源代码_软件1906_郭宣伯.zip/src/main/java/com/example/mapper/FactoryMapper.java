package com.example.mapper;

import com.example.entity.Factory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface FactoryMapper extends BaseMapper<Factory> {

}
