package com.example.mapper;

import com.example.entity.DeviceType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface DeviceTypeMapper extends BaseMapper<DeviceType> {

}
