package com.example.service;

import com.example.entity.Factory;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.mapper.FactoryMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class FactoryService extends ServiceImpl<FactoryMapper, Factory> {

    @Resource
    private FactoryMapper factoryMapper;

}
